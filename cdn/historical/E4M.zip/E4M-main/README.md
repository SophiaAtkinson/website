# E4M

---

### Encryption For The Masses

### I found the history for E4M intresting so I decided to give the downloads for it, since it was closed.

---

Version for Windows 95/98/NT

E4M201.exe

E4M201s.zip

mkproto.zip

---

Older version with NT support only

E4M200.exe

E4M200s.zip
